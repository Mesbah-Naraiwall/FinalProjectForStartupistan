const cluster = require('cluster');
if(cluster.isMaster){
    var i = 0
    for(i; i<2; i++){
        cluster.fork();
    }
    cluster.on('exit', (worker)=>{
        console.log('worker ' + worker.id + " died...")
        cluster.fork()
    })
}else{
const express = require("express");
const app = express();
app.use(express.json())
// const nodemailer = require("nodemailer");
require("dotenv").config();
var mongoose = require('mongoose')
const cors = require("cors")
const multer = require('multer');
const path = require('path'); 
var url = "mongodb://localhost:27017/YouthFinalPro"
app.use(cors());
app.use(express.urlencoded());

const contactRoute = require('./routes/ContactRoute/contactRoute');
const popularCourse = require('./routes/CoursesRoute/PopularRoute');
const Instructor = require('./routes/Instructor/InstructorRoute');
const Testmonial = require('./routes/Testmonial/TestmonialRoute');
const Employees = require('./routes/EmployeesRoute/EmployeesRoute');
const Students = require('./routes/StudentsRoute/StudentsRoute');
const Login = require('./routes/Login/Login');
const auth = require('./routes/Auth/auth');
// const auth = require('../frontend-react/public/upload');






mongoose.connect(url)
const port = 4000;


app.use(cors())
// =============All Routes===========
app.use('/', contactRoute);
app.use('/', popularCourse);
app.use('/', Instructor);
app.use('/', Testmonial);
app.use('/', Employees);
app.use('/', Students);
app.use('/', Login);

app.get("/auth-endpoint", auth, (request, response) => {
  response.json({ message: "You are authorized to access me" });
});

// Curb Cores Error by adding a header here
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content, Accept, Content-Type, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, PATCH, OPTIONS"
  );
  next();
});

const storage = multer.diskStorage({
  destination: (req,file,cb)=>{
      cb(null,"../frontend-react/public/upload")
  },
  filename : (req,file,cb)=>{
      cb(null,Date.now()+ file.originalname)
  }
})
const upload = multer({storage})
// ========Upload image API================
app.post('/image',upload.single("file"),(req,res)=>{
  const file = req.file;
  // const file = "image.jpg";
  res.status(200).json(file.filename);
})



app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
 });
}

// let transporter = nodemailer.createTransport({
//     service: "gmail",
//     auth: {
//       type: "OAuth2",
//       user: process.env.EMAIL,
//       pass: process.env.WORD,
//       clientId: process.env.OAUTH_CLIENTID,
//       clientSecret: process.env.OAUTH_CLIENT_SECRET,
//       refreshToken: process.env.OAUTH_REFRESH_TOKEN,
//     },
//    });

