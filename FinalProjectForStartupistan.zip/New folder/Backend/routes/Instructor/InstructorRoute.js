const router = require("express").Router();
const mongoose = require('mongoose');
const Instructor = require('../../models/Instructor/instructor')

// ==================Create New About=======================
router.post('/instructor', async (req, res)=>{
    const {nameOfInstructor, field} = req.body;
    try{
        const instructor = await Instructor.create({nameOfInstructor, field})
        res.status(200).json(instructor)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})
// // ==================Show Single instructors=======================
router.get('/instructor/:id', async (req, res)=>{
    var instructorId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(instructorId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    const instructor = await Instructor.findById(instructorId)
    if(!instructor){
        return res.status(404).json({error:"No instructors by This id exsit!"})
    }
    res.status(200).json(instructor)
})
// // ==================Show all instructors=========================
router.get('/instructor', async (req, res) => {
    const instructors = await Instructor.find({}).sort({createAt: -1})
    res.status(200).json(instructors);
})

// // ==================Update a Single instructors=================
router.patch('/instructor/:id', async (req,res)=>{
    var instructorId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(instructorId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const instructor  = await Instructor.findById(instructorId)
        if(instructor.username === req.body.username){
            try{
                const updataInstructor = await Instructor.findByIdAndUpdate(instructorId, {$set:req.body},{new:true})
                res.status(200).json(updataInstructor)
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can update your instructors Only!"})
        }
    }catch(error){
        res.status(500).json(error)
    }
})

// // ==================Delete A instructors=======================
router.delete('/instructor/:id', async (req, res)=>{
    var instructorId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(instructorId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const instructors  = await Instructor.findById(instructorId)
        if(instructors.username === req.body.username){
            try{
                await instructors.delete()
                res.status(200).json({message:"instructors Deleted!"})
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can Delete your instructors Only!"})
        }
    }catch(erorr){
        res.status(500).json(erorr)
    }
})


module.exports = router