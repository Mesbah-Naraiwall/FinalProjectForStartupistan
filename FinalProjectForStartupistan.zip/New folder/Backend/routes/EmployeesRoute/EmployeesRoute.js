const router = require("express").Router();
const mongoose = require('mongoose');
const Employees = require('../../models/Employees/employees')

// ==================Create New About=======================
router.post('/employee', async (req, res)=>{
    const {employeeId, name, position, education, joiningDate, contractDuration, project} = req.body;
    try{
        const employee = await Employees.create({employeeId, name, position, education, joiningDate, contractDuration, project})
        res.status(200).json(employee)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})
// // ==================Show Single employees=======================
router.get('/employee/:id', async (req, res)=>{
    var employeeId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(employeeId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    const employee = await Employees.findById(employeeId)
    if(!employee){
        return res.status(404).json({error:"No employees by This id exsit!"})
    }
    res.status(200).json(employee)
})
// // ==================Show all employees=========================
router.get('/employee', async (req, res) => {
    const employees = await Employees.find({}).sort({createAt: -1})
    res.status(200).json(employees);
})

// // ==================Update a Single employees=================
router.patch('/employee/:id', async (req,res)=>{
    var employeeId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(employeeId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const employee  = await Employees.findById(employeeId)
        if(employee.username === req.body.username){
            try{
                const updataemployee = await Employees.findByIdAndUpdate(employeeId, {$set:req.body},{new:true})
                res.status(200).json(updataemployee)
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can update your employees Only!"})
        }
    }catch(error){
        res.status(500).json(error)
    }
})

// // ==================Delete A employees=======================
router.delete('/employee/:id', async (req, res)=>{
    var employeeId = req.params.id
    if(!mongoose.Types.ObjectId.isValid(employeeId)){
        return res.status(404).json({erorr:"invalid Id Requisted"})
    }
    try{
        const employees  = await Employees.findById(employeeId)
        if(employees.username === req.body.username){
            try{
                await employees.delete()
                res.status(200).json({message:"employees Deleted!"})
            }catch(error){
                res.status(500).json(error)
            }
        }else{
            res.status(401).json({message:"you can Delete your employees Only!"})
        }
    }catch(erorr){
        res.status(500).json(erorr)
    }
})


module.exports = router