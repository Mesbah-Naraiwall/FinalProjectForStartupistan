const mongoose = require('mongoose')

const StudentsSchema = mongoose.Schema({
    studnetId:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    fatherName:{
        type: String,
        required: true
    },
    education:{
        type: String,
        required: true
    }, 
    field:{
        type: String,
        required: true
    },
    phone:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    },
    batch:{
        type: String,
        required: true
    },
    program:{
        type: String,
        required: true
    },
    githubFinalProjectLink:{
        type: String,
        required: true
    },
},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("Students", StudentsSchema)