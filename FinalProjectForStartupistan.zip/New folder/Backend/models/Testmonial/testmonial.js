const mongoose = require('mongoose')

const TestmonialSchema = mongoose.Schema({
    nameOfStudent:{
        type: String,
        required: true
    },
    field:{
        type: String,
        required: true
    },
    commet:{
        type: String,
        required: true
    }, 
    image:{
        type: String,
        required: true
    },
},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("Testmonial", TestmonialSchema)