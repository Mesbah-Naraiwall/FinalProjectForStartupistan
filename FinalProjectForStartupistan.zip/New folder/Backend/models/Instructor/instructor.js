const mongoose = require('mongoose')

const Instructor = mongoose.Schema({
    nameOfInstructor:{
        type: String,
        required: true
    },
    field:{
        type: String,
        required: true
    },
 
    


},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("Instructor", Instructor)