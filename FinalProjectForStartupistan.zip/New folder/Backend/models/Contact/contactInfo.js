const mongoose = require('mongoose')

const ContactInfoSchema = mongoose.Schema({
    office:{
        type: String,
        required: true
    },
    mobile:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    },
    googleMap:{
        type: String,
        required: true
    },
    aboutTitle:{
        type: String,
        required: true
    },
    bodyPar:{
        type: String,
        required: true
    },
    coverImage:{
        type: String,
        required: true
    },

    
},{timestamps: true}) // it take automaticlly time 

module.exports = mongoose.model("Contact Table", ContactInfoSchema);