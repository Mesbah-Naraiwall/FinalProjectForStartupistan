import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";
import moment from 'moment'


export default function TeatmonialData(){
    // ==================================get data ================

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([])

// ==================================get data ================
    useEffect(() => {
      fetchData();
    }, []);
    // ==================================get data ================
    const fetchData = async () =>{
      setLoading(true);
      try {
        const {data: response} = await axios.get('http://localhost:4000/testmonial');
        setData(response);
        console.log(data);
      } catch (error) {
        console.error(error.message);
      }
      setLoading(false);
    }
// ===========================================delete data =========================
  const deleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/testmonial/${id}`);
      fetchData();
    } catch (error) {
      console.log(error);
    }
  };

    return(
        <div className="table-responsive">
        <h1>Teatmonial Table</h1>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Name Of Instructor</th>
                    <th>Field</th>
                    <th>Comment</th>
                    <th>Image Url</th>
                    <th></th>
                </tr>
                </thead>
        {data.map(item => (<tbody>
            <tr>
            <td>{item.nameOfStudent}</td>
            <td>{item.field}</td>
            <td>{item.commet}</td>
            <td>{item.image}</td>
            <td>
                <Link to={`/updatetestmonial/`} state={item}   >
                
                <button className="btn btn-info" >Edit</button>
                </Link>
                </td>
            <td><button onClick={() => deleteUser(item._id)} className="btn btn-danger">Delete</button></td>
            </tr>
        </tbody>
        ))}
            <Link className="btn btn-success" to="/addtestmonial">Add Student</Link>
            </table>
        </div>
      )}