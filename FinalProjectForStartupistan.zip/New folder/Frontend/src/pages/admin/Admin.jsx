import React from "react";
// import './css/sb-admin-2.css';
import './admin.css'
import pic from '../course-2.jpg';
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";
import UpdateStudent from "./student/UpdateStudent";

export default function Admin(){
  return(
    <div className="container-xxl py-5" style={{overflowX:'hidden'}}>
        <h1 className="mb-4">Welcome to admin page</h1>
    </div>
  )
   }