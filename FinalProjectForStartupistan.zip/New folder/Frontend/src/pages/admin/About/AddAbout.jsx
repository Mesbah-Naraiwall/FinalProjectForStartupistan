import React, { useState } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================student data================
export default function AddAbout(){
const [aboutTitle, setAboutTitle] = useState('');
const [bodyPar, setBodyPar] = useState('');
const [coverImage, setCoverImage] = useState('');


const navigate = useNavigate();

// ===========================================add data =========================
const saveTeam = async (e) => {
    e.preventDefault();
    try{
    await axios.post(`http://localhost:4000/contactinfo`,
    {
        aboutTitle,
        bodyPar,
        coverImage,
    });
    navigate("/aboutdata");
    } catch(error){
        console.log(error);
    }
  };
// ===========================
  return(
  <div className="container">
    <h1>Add Instructor</h1>
    <form onSubmit={saveTeam}>
    <div className="form-group">
            <label for="aboutTitle">About Title</label>
            <input type="text" 
            class="form-control"
            value={aboutTitle}
            id="aboutTitle" 
            placeholder="About Title"
            onChange={(e) => setAboutTitle(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="bodyPar">bodyPar</label>
            <input type="text" 
            class="form-control"
            value={bodyPar}
            id="bodyPar" 
             placeholder="Body paragraph"
            onChange={(e) => setBodyPar(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="bodyPar">Cover Photo</label>
            <input type="text" 
            class="form-control"
            value={coverImage}
            id="bodyPar" 
             placeholder="Cover Photo"
            onChange={(e) => setCoverImage(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
  </div>
)}