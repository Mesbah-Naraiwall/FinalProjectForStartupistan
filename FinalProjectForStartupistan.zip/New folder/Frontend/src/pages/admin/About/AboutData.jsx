import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";
import moment from 'moment'


export default function AboutData(){
    // ==================================get data ================

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([])

// ==================================get data ================
    useEffect(() => {
      fetchData();
    }, []);
    // ==================================get data ================
    const fetchData = async () =>{
      setLoading(true);
      try {
        const {data: response} = await axios.get('http://localhost:4000/contactinfo');
        setData(response);
        console.log(data);
      } catch (error) {
        console.error(error.message);
      }
      setLoading(false);
    }
// ===========================================delete data =========================
  const deleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/contactinfo/${id}`);
      fetchData();
    } catch (error) {
      console.log(error);
    }
  };

    return(
        <div className="table-responsive">
        <h1>Teatmonial Table</h1>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>About Title</th>
                    <th>Body Paragraph</th>
                    <th>Image Url</th>
                    <th></th>
                </tr>
                </thead>
        {data.map(item => (<tbody>
            <tr>
            <td>{item.aboutTitle}</td>
            <td>{item.bodyPar}</td>
            <td>{item.coverImage}</td>
            <td>
                <Link to={`/updateabout/`} state={item}   >
                
                <button className="btn btn-info" >Edit</button>
                </Link>
                </td>
            <td><button onClick={() => deleteUser(item._id)} className="btn btn-danger">Delete</button></td>
            </tr>
        </tbody>
        ))}
            <Link className="btn btn-success" to="/addabout">Add About</Link>
            </table>
        </div>
      )}