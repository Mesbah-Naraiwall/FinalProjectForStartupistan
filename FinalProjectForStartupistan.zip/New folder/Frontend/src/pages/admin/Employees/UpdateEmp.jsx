import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================employee data================
export default function UpdateEmp(userId){
const [employeeId, setEmployeeId] = useState('');
const [name, setName] = useState('');
const [position, setPosition] = useState('');
const [contractDuration, setContractDuration] = useState('');
const [project, setProject] = useState('');
const [education, setEducation] = useState('');
const [joiningDate, setJoiningDate] = useState('');
const { _id } = useParams();

const state = useLocation().state;



const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getEmpById();
  }, []);

// ===========================================UPDATE data =========================
const getEmpById = async () => {
    const response = await axios.get(`http://localhost:4000/employee/${state._id}`);

    setEmployeeId(response.data.employeeId);
    setName(response.data.name);
    setPosition(response.data.position);
    setContractDuration(response.data.contractDuration);
    setProject(response.data.project);
    setEducation(response.data.education);
    setJoiningDate(response.data.joiningDate);
  };
// ===========================
const updateEmp = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/employee/${state._id}`, {
        employeeId,
        name,
        position,
        education,
        contractDuration,
        project,
        joiningDate,
      });
      navigate("/empdata");
    } catch (error) {
      console.log(error);
    }
  };
  return(
  <div className="container">
    <h1>Update Student</h1>
    <form onSubmit={updateEmp}>
    <div className="form-group">
            <label for="aid">Employee Id</label>
            <input type="text" 
            class="form-control"
            value={employeeId}
            id="sid" 
            placeholder="employeeId"
            onChange={(e) => setEmployeeId(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="name">Name</label>
            <input type="text" 
            class="form-control"
            value={name}
            id="name" 
             placeholder="Name"
            onChange={(e) => setName(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Father Name</label>
            <input type="text" 
            class="form-control"
            value={position}
            id="father" 
            placeholder="Father Name"
            onChange={(e) => setPosition(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Education</label>
            <input type="text" 
            class="form-control"
            value={education}
            id="father" 
            placeholder="Education"
            onChange={(e) => setEducation(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Phone</label>
            <input type="text" 
            class="form-control"
            value={contractDuration}
            id="father" 
            placeholder="Phone"
            onChange={(e) => setContractDuration(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Email</label>
            <input type="project" 
            class="form-control"
            value={project}
            id="father" 
            placeholder="Email"
            onChange={(e) => setProject(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-success">Edit</button>
        </form>
  </div>
)}