import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";

// ==================================student data================
export default function UpdateStudent(userId){
const [studnetId, setStudnetId] = useState('');
const [name, setName] = useState('');
const [fatherName, setFatherName] = useState('');
const [education, setEducation] = useState('');
const [field, setField] = useState('');
const [phone, setPhone] = useState('');
const [email, setEmail] = useState('');
const [batch, setBatch] = useState('');
const [program, setProgram] = useState('');
const [githubFinalProjectLink, setGithubFinalProjectLink] = useState('');
const { _id } = useParams();

const state = useLocation().state;



const navigate = useNavigate();
// ==================================get data ================

useEffect(() => {
    getStudnetById();
  }, []);

// ===========================================UPDATE data =========================
const getStudnetById = async () => {
    const response = await axios.get(`http://localhost:4000/student/${state._id}`);

    setStudnetId(response.data.studnetId);
    setName(response.data.name);
    setFatherName(response.data.fatherName);
    setEducation(response.data.education);
    setField(response.data.field);
    setPhone(response.data.phone);
    setEmail(response.data.email);
    setBatch(response.data.batch);
    setProgram(response.data.program);
    setGithubFinalProjectLink(response.data.githubFinalProjectLink);
   
   
  };
// ===========================
const updateStudents = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:4000/student/${state._id}`, {
        studnetId,
        name,
        fatherName,
        education,
        field,
        phone,
        email,
        batch,
        program,
        githubFinalProjectLink
      });
      navigate("/studentdata");
    } catch (error) {
      console.log(error);
    }
  };
  return(
  <div className="container">
    <h1>Update Student</h1>
    <form onSubmit={updateStudents}>
    <div className="form-group">
            <label for="aid">Student ID</label>
            <input type="text" 
            class="form-control"
            value={studnetId}
            id="sid" 
            placeholder="Student ID"
            onChange={(e) => setStudnetId(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="name">Name</label>
            <input type="text" 
            class="form-control"
            value={name}
            id="name" 
             placeholder="Name"
            onChange={(e) => setName(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Father Name</label>
            <input type="text" 
            class="form-control"
            value={fatherName}
            id="father" 
            placeholder="Father Name"
            onChange={(e) => setFatherName(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Education</label>
            <input type="text" 
            class="form-control"
            value={education}
            id="father" 
            placeholder="Education"
            onChange={(e) => setEducation(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Field</label>
            <input type="text" 
            class="form-control"
            value={field}
            id="father" 
            placeholder="Field"
            onChange={(e) => setField(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Phone</label>
            <input type="text" 
            class="form-control"
            value={phone}
            id="father" 
            placeholder="Phone"
            onChange={(e) => setPhone(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Email</label>
            <input type="email" 
            class="form-control"
            value={email}
            id="father" 
            placeholder="Email"
            onChange={(e) => setEmail(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Batch</label>
            <input type="text" 
            class="form-control"
            value={batch}
            id="father" 
            placeholder="Batch"
            onChange={(e) => setBatch(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Program</label>
            <input type="text" 
            class="form-control"
            value={program}
            id="father" 
            placeholder="Program"
            onChange={(e) => setProgram(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="father">Github Final Project Link</label>
            <input type="text" 
            class="form-control"
            value={githubFinalProjectLink}
            id="father" 
            placeholder="Github Final Project Link"
            onChange={(e) => setGithubFinalProjectLink(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Edit</button>
        </form>
  </div>
)}