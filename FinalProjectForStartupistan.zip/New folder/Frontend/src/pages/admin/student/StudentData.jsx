import React from "react";
// import './css/sb-admin-2.css';
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";

export default function StudentData(){
    // ==================================get data ================

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([])

// ==================================get data ================

    useEffect(() => {
      fetchData();
    }, []);
    // ==================================get data ================
    const fetchData = async () =>{
      setLoading(true);
      try {
        const {data: response} = await axios.get('http://localhost:4000/student');
        setData(response);
        console.log(data);
      } catch (error) {
        console.error(error.message);
      }
      setLoading(false);
    }
// ===========================================delete data =========================
  const deleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/student/${id}`);
      fetchData();
    } catch (error) {
      console.log(error);
    }
  };

    return(
        <div className="table-responsive">
        <h1>Student Table</h1>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Studnet Id</th>
                    <th>Name</th>
                    <th>Father Name</th>
                    <th>Education</th>
                    <th>Field</th>
                    <th>Phone</th>
                    <th>Batch</th>
                    <th>Program</th>
                    <th>githubFinalProjectLink</th>
                    <th></th>
                </tr>
              </thead>
      {data.map(item => (<tbody>
          <tr>
            <td>{item.studnetId}</td>
            <td>{item.name}</td>
            <td>{item.fatherName}</td>
            <td>{item.education}</td>
            <td>{item.field}</td>
            <td>{item.phone}</td>
            <td>{item.batch}</td>
            <td>{item.program}</td>
            <td>{item.githubFinalProjectLink}</td>
            <td>
                <Link to={`/updateStudent/`} state={item}   >
                
                <button className="btn btn-info" >Edit</button>
                </Link>
                </td>
            <td><button onClick={() => deleteUser(item._id)} className="btn btn-danger">Delete</button></td>
            </tr>
        </tbody>
        ))}
            <Link className="btn btn-primary" to="/addstudent">Add Student</Link>
            </table>
        </div>
      )}