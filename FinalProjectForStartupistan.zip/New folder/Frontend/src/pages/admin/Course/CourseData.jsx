import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";
import moment from 'moment'


export default function CourseData(){
    // ==================================get data ================

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([])

// ==================================get data ================
    useEffect(() => {
      fetchData();
    }, []);
    // ==================================get data ================
    const fetchData = async () =>{
      setLoading(true);
      try {
        const {data: response} = await axios.get('http://localhost:4000/popularcourse');
        setData(response);
        console.log(data);
      } catch (error) {
        console.error(error.message);
      }
      setLoading(false);
    }
// ===========================================delete data =========================
  const deleteCourse = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/popularcourse/${id}`);
      fetchData();
    } catch (error) {
      console.log(error);
    }
  };

    return(
        <div className="table-responsive">
        <h1>Courses Table</h1>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Name Of Course</th>
                    <th>Instructor</th>
                    <th>Rating</th>
                    <th>Description</th>
                    <th>Hours</th>
                    <th>Student Members</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th></th>
                </tr>
                </thead>
        {data.map(item => (<tbody>
            <tr>
            <td>{item.nameOfCourse}</td>
            <td>{item.instructor}</td>
            <td>{item.rating}</td>
            <td>{item.desc}</td>
            <td>{item.hours}</td>
            <td>{item.studentMembers}</td>
            <td>{item.price}</td>
            <td>{item.image}</td>
            <td>
                <Link to={`/updatecourse/`} state={item}   >
                
                <button className="btn btn-info" >Edit</button>
                </Link>
                </td>
            <td><button onClick={() => deleteCourse(item._id)} className="btn btn-danger">Delete</button></td>
            </tr>
        </tbody>
        ))}
            <Link className="btn btn-success" to="/addcourse">Add Course</Link>
            </table>
        </div>
      )}