import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";
// import EmployeeData from './EmployeeData'
import moment from "moment";

// ==================================student data================
export default function AddCourse(){
const [nameOfCourse, setNameOfCourse] = useState('');
const [instructor, setInstructor] = useState('');
const [rating, setRating] = useState('');
const [desc, setDesc] = useState('');
const [hours, setHours] = useState('');
const [studentMembers, setStudentMembers] = useState('');
const [price, setPrice] = useState('');
// const [file, setFile] = useState('');
const [file, setFile] = useState(null)

const navigate = useNavigate();

// ===========================================add data =========================
const saveEmp = async (e) => {
    const newCourse = {
      nameOfCourse,
      instructor,
      rating,
      price,
      desc,
      hours,
      studentMembers,
  }
    e.preventDefault();
    if (file) {
      const data = new FormData();
      const filename = Date.now() + file.name;
      data.append("name", filename);
      data.append("file", file);
      newCourse.image = filename;
      try {
        await axios.post("http://localhost:4000/image", data);
      } catch (err) {
        alert(err)
      }
    }
    try{
      const res = await axios.post(`http://localhost:4000/popularcourse`, newCourse
    );
    // navigate("/coursedata");
     window.location.replace("/coursedata/" + res.data);

    } catch(error){
      console.log(error);
    }
  };
// ===========================
  return(
  <div className="container">
    <h1>Add Course</h1>
    <form onSubmit={saveEmp}>
    <div className="form-group">
            <label for="nameOfCourse">Name Of Course</label>
            <input type="text" 
            class="form-control"
            id="nameOfCourse" 
            value={nameOfCourse}
            placeholder="Name Of Course"
            onChange={(e) => setNameOfCourse(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="instructor">Instructor</label>
            <input type="text" 
            class="form-control"
            value={instructor}
            id="instructor" 
             placeholder="instructor"
            onChange={(e) => setInstructor(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Rating">Rating</label>
            <input type="number" 
            class="form-control"
            id="Rating" 
            value={rating}
            placeholder="Rating"
            onChange={(e) => setRating(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Price">Price</label>
            <input type="decimal" 
            class="form-control"
            value={price}
            id="Price" 
            placeholder="Price"
            onChange={(e) => setPrice(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="hours">Hours</label>
            <input type="number" 
            class="form-control"
            id="hours" 
            value={hours}
            placeholder="Hours"
            onChange={(e) => setHours(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="Description">Course Description</label>
            <input type="text" 
            class="form-control"
            id="Description" 
            value={desc}
            placeholder="Course Description"
            onChange={(e) => setDesc(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="studentMembers">Student Members</label>
            <input type="number" 
            class="form-control"
            id="studentMembers" 
            value={studentMembers}
            placeholder="studentMembers"
            onChange={(e) => setStudentMembers(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            {/* <label for="file">file</label> */}
            <input type="file" 
            class="form-control"
            // id="file" 
            // value={file}
            // placeholder="file"
            onChange={(e)=>setFile(e.target.files[0])}            />
        </div>

        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
  </div>
)}
