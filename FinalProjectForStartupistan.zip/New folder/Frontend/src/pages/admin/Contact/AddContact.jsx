import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate, useParams } from "react-router-dom";
// import EmployeeData from './EmployeeData'
import moment from "moment";

// ==================================student data================
export default function AddEmp(){
const [office, setoffice] = useState('');
const [mobile, setMobile] = useState('');
const [email, setEmail] = useState('');
const [googleMap, setGoogleMap] = useState('');

const navigate = useNavigate();

// ===========================================add data =========================
const saveContact = async (e) => {
    e.preventDefault();
    try{
    await axios.post(`http://localhost:4000/contactinfo`,
    {
        office,
        mobile,
        email,
        googleMap,
    });
    navigate("/contactdata");
    } catch(error){
        console.log(error);
    }
  };
// ===========================
  return(
  <div className="container">
    <h1>Add Contact</h1>
    <form onSubmit={saveContact}>
    <div className="form-group">
            <label for="office">Office</label>
            <input type="text" 
            class="form-control"
            value={office}
            id="office" 
            placeholder="office"
            onChange={(e) => setoffice(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="mobile">mobile</label>
            <input type="text" 
            class="form-control"
            value={mobile}
            id="mobile" 
             placeholder="Name"
            onChange={(e) => setMobile(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="email">Email</label>
            <input type="email" 
            class="form-control"
            value={email}
            id="email" 
            placeholder="Email"
            onChange={(e) => setEmail(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <div className="form-group">
            <label for="googleMap">Google Map</label>
            <input type="text" 
            class="form-control"
            value={googleMap}
            id="googleMap" 
            placeholder="googleMap"
            onChange={(e) => setGoogleMap(e.target.value)}
            />
        </div>
        {/* ============================= */}
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
  </div>
)}