import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";
import moment from 'moment'


export default function ContactData(){
    // ==================================get data ================

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([])

// ==================================get data ================
    useEffect(() => {
      fetchData();
    }, []);
    // ==================================get data ================
    const fetchData = async () =>{
      setLoading(true);
      try {
        const {data: response} = await axios.get('http://localhost:4000/contactinfo');
        setData(response);
        console.log(data);
      } catch (error) {
        console.error(error.message);
      }
      setLoading(false);
    }
// ===========================================delete data =========================
  const deleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/contactinfo/${id}`);
      fetchData();
    } catch (error) {
      console.log(error);
    }
  };

    return(
        <div className="table-responsive">
        <h1>Contact Table</h1>
            <table className="table table-hover table-info table-sm">
                <thead>
                <tr>
                    <th>Office</th>
                    <th>Mobile</th>
                    <th>Email</th>
                    <th>GoogleMap</th>
                    <th></th>
                </tr>
                </thead>
        {data.map(item => (<tbody>
            <tr>
            <td>{item.office}</td>
            <td>{item.mobile}</td>
            <td>{item.email}</td>
            <td>{item.googleMap}</td>
            <td>
                <Link to={`/updatecontact/`} state={item}   >
                
                <button className="btn btn-info" >Edit</button>
                </Link>
                </td>
            <td><button onClick={() => deleteUser(item._id)} className="btn btn-danger">Delete</button></td>
            </tr>
        </tbody>
        ))}
            <Link className="btn btn-success" to="/addcontact">Add Contact</Link>
            </table>
        </div>
      )}