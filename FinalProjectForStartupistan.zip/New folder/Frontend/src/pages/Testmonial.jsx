import React from "react";
import pic from './course-2.jpg'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import { useState, useEffect } from "react";
import axios from "axios";

export default function (){
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState([])
  
    useEffect(() => {
      const fetchData = async () =>{
        setLoading(true);
        try {
          const {data: response} = await axios.get('http://localhost:4000/testmonial');
          setData(response);
        } catch (error) {
          console.error(error.message);
        }
        setLoading(false);
      }
      fetchData();
    }, []);
    return(
            <div className="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
                <div className="container">
                    <div className="text-center">
                        <h6 className="section-title bg-white text-center text-primary px-3">Testimonial</h6>
                        <h1 className="mb-5">Our Students Say!</h1>
                    </div>
                    <OwlCarousel className='owl-theme' loop margin={8}>
                    {data.map(item => (
                        <div className="text-center item">
                            <img className="border rounded-circle p-2 mx-auto mb-3" src={pic} style={{width: "80px", height: "80px"}}/>
                            <h5 className="mb-0">{item.nameOfStudent}</h5>
                            <p>{item.field}</p>
                            <div className="testimonial-text bg-light text-center p-4">
                            <p className="mb-0">{item.commet}</p>
                            </div>
                        </div>
                        ))}
                    </OwlCarousel>
                </div>
            </div>
    )
}