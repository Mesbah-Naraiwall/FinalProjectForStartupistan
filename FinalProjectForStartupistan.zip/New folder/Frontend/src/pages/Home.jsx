import React from "react";
import pic from './download.jpeg';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import Testmonial from './Testmonial'
import Courses from './Courses';
import Team from './Team';
import About from './About';

export default function Home(){
    return(
<div>
    {/* <!-- Carousel Start --> */}
    {/* <img className="img-fluid" style={{cover: "fit", width: "100%", height: "40em"}} src={pic}  alt=""/>
    <div className="container-fluid p-0 mb-5">
        <div className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style={{background: "rgba(24, 29, 56, .7)"}}>
            <div className="container">
                <div className="row justify-content-start">
                    <div className="col-sm-10 col-lg-8">
                        <h5 className="text-primary text-uppercase mb-3 animated slideInDown">Best Online Courses</h5>
                        <h3 className="display-3 text-white animated slideInDown">The Best Online Learning Platform</h3>
                        <p className="fs-5 text-white mb-4 pb-2">Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea sanctus eirmod elitr.</p>
                        <a href="" className="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                        <a href="" className="btn btn-light py-md-3 px-md-5 animated slideInRight">Join Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div> */}
    {/* ======================== */}

<div id="carouselExampleDark" className="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
  </div>
  <div className="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src={pic} class="d-block w-100" alt="..."/>
      <div class="carousel-caption d-none d-md-block">
        <div className="row justify-content-center">
            <div className="col-sm-10 col-lg-8">
                <h5 className="text-primary text-uppercase mb-3 animated slideInDown">Best Online Courses</h5>
                <h3 className="display-3 text-white animated slideInDown">The Best Online Learning Platform</h3>
                <p className="fs-5 text-white mb-4 pb-2">Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea sanctus eirmod elitr.</p>
                <a href="" className="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                <a href="" className="btn btn-light py-md-3 px-md-5 animated slideInRight">Join Now</a>
            </div>
        </div>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="2000">
    <img src={pic} class="d-block w-100" alt="..."/>
      <div class="carousel-caption d-none d-md-block">
        <div className="row justify-content-center">
            <div className="col-sm-10 col-lg-8">
                <h5 className="text-primary text-uppercase mb-3 animated slideInDown">Best Online Courses</h5>
                <h3 className="display-3 text-white animated slideInDown">The Best Online Learning Platform</h3>
                <p className="fs-5 text-white mb-4 pb-2">Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea sanctus eirmod elitr.</p>
                <a href="" className="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                <a href="" className="btn btn-light py-md-3 px-md-5 animated slideInRight">Join Now</a>
            </div>
        </div>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    {/* <!-- About Start --> */}
    {/* <div className="container-xxl py-5">
        <div className="container">
            <div className="row g-5">
                <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style={{minHeight: "400px"}}>
                    <div className="position-relative h-100">
                        <img className="img-fluid position-absolute w-100 h-100" src={pic} alt="" style={{objectFit: "cover"}}/>
                    </div>
                </div>
                <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 className="section-title bg-white text-start text-primary pe-3">About Us</h6>
                    <h1 className="mb-4">Welcome to eLEARNING</h1>
                    <p className="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                    <p className="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
                    <div className="row gy-2 gx-4 mb-4">
                        <div className="col-sm-6">
                            <p className="mb-0"><i className="fa fa-arrow-right text-primary me-2"></i>Skilled Instructors</p>
                        </div>
                        <div className="col-sm-6">
                            <p className="mb-0"><i className="fa fa-arrow-right text-primary me-2"></i>Online ClassNamees</p>
                        </div>
                        <div className="col-sm-6">
                            <p className="mb-0"><i className="fa fa-arrow-right text-primary me-2"></i>International Certificate</p>
                        </div>
                        <div className="col-sm-6">
                            <p className="mb-0"><i className="fa fa-arrow-right text-primary me-2"></i>Skilled Instructors</p>
                        </div>
                        <div className="col-sm-6">
                            <p className="mb-0"><i className="fa fa-arrow-right text-primary me-2"></i>Online ClassNamees</p>
                        </div>
                        <div className="col-sm-6">
                            <p className="mb-0"><i className="fa fa-arrow-right text-primary me-2"></i>International Certificate</p>
                        </div>
                    </div>
                    <a className="btn btn-primary py-3 px-5 mt-2" href="">Read More</a>
                </div>
            </div>
        </div>
    </div> */}
    <About/>
    {/* <!-- Categories Start --> */}
    <Courses/>
    {/* <!-- Team Start --> */}
    <Team/>
    {/* <!-- Testimonial Start --> */}
    <Testmonial/>
</div>
    )
}