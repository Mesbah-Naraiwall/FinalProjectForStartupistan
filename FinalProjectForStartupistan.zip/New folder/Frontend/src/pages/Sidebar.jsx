import React from "react";
// import './css/sb-admin-2.css';
import { useState, useEffect } from "react";
import axios from "axios";
import {Link, useNavigate, useParams } from "react-router-dom";


export default function example(){
    return(
        <div className="container-xxl py-5">
    <main className=" ">        
            <div className="col-sm bg-light" style={{width: "280px"}}>
                <Link to="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
                <svg className="bi me-2" width="40" height="32"><use href="#bootstrap"/></svg>
                <span className="fs-4">Admin Page</span>
                </Link>
                <hr/>
                <ul className="nav nav-pills flex-column mb-auto">
                <li className="nav-item">
                    <Link to="/" className="nav-link active" aria-current="page">
                    <svg className="bi me-2" width="16" height="16"><use href="#home"/></svg>
                    Back to Home
                    </Link>
                </li>
                <li>
                    <Link to="/studentdata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    Student Data
                    </Link>
                </li>
                <li>
                    <Link to="empdata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    Employees
                    </Link>
                </li>
                <li>
                    <Link to="/coursedata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    Courses
                    </Link>
                </li>
                <li>
                    <Link to="/teamdata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    Team
                    </Link>
                </li>
                <li>
                    <Link to="/testmonialdata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    Testmonial
                    </Link>
                </li>
                <li>
                    <Link to="/contactdata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    Contact
                    </Link>
                </li>
                <li>
                    <Link to="/aboutdata" className="nav-link link-dark">
                    <svg className="bi me-2" width="16" height="16"><use/></svg>
                    About Us
                    </Link>
                </li>
                </ul>
                <hr/>
                <div className="dropdown">
                <a href="#" className="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                    {/* <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2"/> */}
                    <strong>Setting</strong>
                </a>
                <ul className="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
                    <li><a className="dropdown-item" href="#">Profile</a></li>
                    <li><hr className="dropdown-divider"/></li>
                    <li><a className="dropdown-item" href="#">Sign out</a></li>
                </ul>
                </div>
            </div>
  </main>
  </div>
    )
}